/*
   igraph library.
   Copyright (C) 2012-2025  The igraph development team <igraph@igraph.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef IGRAPH_MATCHING_H
#define IGRAPH_MATCHING_H

#include "igraph_decls.h"
#include "igraph_datatype.h"
#include "igraph_error.h"
#include "igraph_types.h"
#include "igraph_vector.h"

IGRAPH_BEGIN_C_DECLS

/* -------------------------------------------------- */
/* Matchings in graphs                                */
/* -------------------------------------------------- */

IGRAPH_EXPORT igraph_error_t igraph_is_matching(const igraph_t* graph,
                                     const igraph_vector_bool_t* types, const igraph_vector_int_t* matching,
                                     igraph_bool_t* result);
IGRAPH_EXPORT igraph_error_t igraph_is_maximal_matching(const igraph_t* graph,
                                             const igraph_vector_bool_t* types, const igraph_vector_int_t* matching,
                                             igraph_bool_t* result);

IGRAPH_EXPORT igraph_error_t igraph_maximum_bipartite_matching(const igraph_t* graph,
                                                    const igraph_vector_bool_t* types, igraph_int_t* matching_size,
                                                    igraph_real_t* matching_weight, igraph_vector_int_t* matching,
                                                    const igraph_vector_t* weights, igraph_real_t eps);

IGRAPH_END_C_DECLS

#endif
