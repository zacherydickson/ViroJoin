/*
   igraph library.
   Copyright (C) 2009-2025  The igraph development team <igraph@igraph.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#ifndef IGRAPH_COCITATION_H
#define IGRAPH_COCITATION_H

#include "igraph_decls.h"
#include "igraph_error.h"
#include "igraph_types.h"
#include "igraph_matrix.h"
#include "igraph_datatype.h"
#include "igraph_iterators.h"

IGRAPH_BEGIN_C_DECLS

/* -------------------------------------------------- */
/* Cocitation and other similarity measures           */
/* -------------------------------------------------- */

IGRAPH_EXPORT igraph_error_t igraph_cocitation(const igraph_t *graph, igraph_matrix_t *res,
                                    igraph_vs_t vids);
IGRAPH_EXPORT igraph_error_t igraph_bibcoupling(const igraph_t *graph, igraph_matrix_t *res,
                                     igraph_vs_t vids);

IGRAPH_EXPORT igraph_error_t igraph_similarity_jaccard(const igraph_t *graph, igraph_matrix_t *res,
                                            igraph_vs_t vit_from, igraph_vs_t vit_to,
                                            igraph_neimode_t mode, igraph_bool_t loops);
IGRAPH_EXPORT igraph_error_t igraph_similarity_jaccard_pairs(const igraph_t *graph, igraph_vector_t *res,
                                                  const igraph_vector_int_t *pairs, igraph_neimode_t mode, igraph_bool_t loops);
IGRAPH_EXPORT igraph_error_t igraph_similarity_jaccard_es(const igraph_t *graph, igraph_vector_t *res,
                                               igraph_es_t es, igraph_neimode_t mode, igraph_bool_t loops);

IGRAPH_EXPORT igraph_error_t igraph_similarity_dice(const igraph_t *graph, igraph_matrix_t *res,
                                         igraph_vs_t vit_from, igraph_vs_t vit_to,
                                         igraph_neimode_t mode, igraph_bool_t loops);
IGRAPH_EXPORT igraph_error_t igraph_similarity_dice_pairs(const igraph_t *graph, igraph_vector_t *res,
                                               const igraph_vector_int_t *pairs, igraph_neimode_t mode, igraph_bool_t loops);
IGRAPH_EXPORT igraph_error_t igraph_similarity_dice_es(const igraph_t *graph, igraph_vector_t *res,
                                            igraph_es_t es, igraph_neimode_t mode, igraph_bool_t loops);

IGRAPH_EXPORT igraph_error_t igraph_similarity_inverse_log_weighted(const igraph_t *graph,
                                                         igraph_matrix_t *res, igraph_vs_t vids,
                                                         igraph_neimode_t mode);

IGRAPH_END_C_DECLS

#endif
