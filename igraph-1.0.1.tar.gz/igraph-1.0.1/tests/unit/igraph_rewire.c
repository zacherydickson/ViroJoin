/*
   igraph library.
   Copyright (C) 2006-2021  The igraph development team <igraph@igraph.org>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/

#include <igraph.h>

#include "operators/rewire_internal.h"

#include "test_utilities.h"

static void check_rewiring(igraph_tree_mode_t tree_mode, igraph_bool_t use_adjlist, igraph_bool_t allow_loops, const char* description) {

    igraph_t g;
    igraph_vector_int_t indegree_before, outdegree_before, indegree_after, outdegree_after;

    igraph_kary_tree(&g, 10, 3, tree_mode);

    igraph_vector_int_init(&indegree_before, 0);
    igraph_vector_int_init(&outdegree_before, 0);
    igraph_degree(&g, &indegree_before, igraph_vss_all(), IGRAPH_IN, IGRAPH_LOOPS);
    igraph_degree(&g, &outdegree_before, igraph_vss_all(), IGRAPH_OUT, IGRAPH_LOOPS);

    igraph_i_rewire(&g, 1000, allow_loops ? IGRAPH_LOOPS_SW : IGRAPH_SIMPLE_SW, use_adjlist, NULL);

    igraph_vector_int_init(&indegree_after, 0);
    igraph_vector_int_init(&outdegree_after, 0);
    igraph_degree(&g, &indegree_after, igraph_vss_all(), IGRAPH_IN, IGRAPH_LOOPS);
    igraph_degree(&g, &outdegree_after, igraph_vss_all(), IGRAPH_OUT, IGRAPH_LOOPS);

    if ((!igraph_vector_int_all_e(&indegree_before, &indegree_after)) ||
        (!igraph_vector_int_all_e(&outdegree_before, &outdegree_after))) {

        print_graph(&g);
        IGRAPH_FATALF("%s: graph degrees changed. Rewired graph is above.\n", description);
    }

    igraph_destroy(&g);
    igraph_vector_int_destroy(&indegree_before);
    igraph_vector_int_destroy(&outdegree_before);
    igraph_vector_int_destroy(&indegree_after);
    igraph_vector_int_destroy(&outdegree_after);

}

int main(void) {
    igraph_rng_seed(igraph_rng_default(), 3925);

    /* Short test for the top-level igraph_rewire() functions (instead of igraph_i_rewire()). */
    {
        igraph_t graph;
        igraph_cycle_graph(&graph, 12, IGRAPH_UNDIRECTED, /* mutual= */ false);
        igraph_rewire(&graph, 50, IGRAPH_SIMPLE_SW, NULL);
        igraph_destroy(&graph);
    }

    check_rewiring(IGRAPH_TREE_OUT, 0, 0, "Directed, no loops, standard-method");
    check_rewiring(IGRAPH_TREE_OUT, 1, 0, "Directed, no loops, adjlist-method");
    check_rewiring(IGRAPH_TREE_OUT, 0, 1, "Directed, loops, standard-method");
    check_rewiring(IGRAPH_TREE_OUT, 1, 1, "Directed, loops, adjlist-method");
    check_rewiring(IGRAPH_TREE_UNDIRECTED, 0, 0, "Undirected, no loops, standard-method");
    check_rewiring(IGRAPH_TREE_UNDIRECTED, 1, 0, "Undirected, no loops, adjlist-method");
    check_rewiring(IGRAPH_TREE_UNDIRECTED, 0, 1, "Undirected, loops, standard-method");
    check_rewiring(IGRAPH_TREE_UNDIRECTED, 1, 1, "Undirected, loops, adjlist-method");

    VERIFY_FINALLY_STACK();
    return 0;
}
