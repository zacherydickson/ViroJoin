
# Null graph, undirected

graph []
